# Switch & Fix: Cloudflare Workers edition

This export preserves the existing React/Vinext website and Black technician hero. It replaces the Sites build integration with standalone Cloudflare Workers configuration. Repository target: https://github.com/Dimpletwit/Switch-FIX

## Upload to GitHub
Extract the ZIP. Upload the CONTENTS of the switch-fix-cloudflare folder to the root of your repository, replacing matching files. Do not upload the ZIP or the enclosing folder. package.json, vite.config.ts and wrangler.jsonc must be at the repository root.

This export omits the old .openai/hosting.json because standalone deployment does not use it. If it remains in an existing repository, it is unused by this configuration. No credentials are included.

## Publish
1. Sign in to https://dash.cloudflare.com.
2. Go to Workers & Pages > Create application > Import a repository. Select GitHub, rather than the drag-and-drop Worker upload method.
3. Authorize Cloudflare for Dimpletwit/Switch-FIX and select that repository.
4. Worker name: switch-fix (must match wrangler.jsonc).
5. Production branch: select the branch where you uploaded these files.
6. Root directory: leave blank when these files are at the repository root.
7. Build command: npm run build
8. Deploy command: npx wrangler deploy
9. Build variable: NODE_VERSION = 22
10. Deploy. Open the workers.dev URL returned by Cloudflare.

Use npm with package-lock.json. If Cloudflare detects pnpm because the original pnpm-lock.yaml is present, delete pnpm-lock.yaml and pnpm-workspace.yaml from the GitHub repository to select npm. They are omitted from this export.

Cloudflare builds can automatically publish changes to the selected production branch. This does not change the existing ChatGPT Sites copy or its URL. The new Cloudflare deployment is a separate copy. Your Cloudflare account controls its public access.

## Local development
Requires Node.js >=22.13.0.

npm ci
npm run dev
npm run build
npx wrangler login
npm run deploy

## Current form behavior
The form prepares a request in the browser and asks the customer to call 843-214-0641. It does not send an email or store submissions on a server.

The original starter tests are retained but do not test the finished website. npm run build verifies compilation. The deployment has not been run against your account by ChatGPT.
